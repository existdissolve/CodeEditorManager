define('ace/snippets/livescript', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "livescript";

});
