CodeEditor
==========

Handy ContentBox module for including and configuring custom code editors.
